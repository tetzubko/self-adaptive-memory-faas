
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'tetzubko',
  applicationName: 'memory-intensive',
  appUid: 'X00J2Zt53995PCBn6r',
  orgUid: '82ceb285-a0fb-4300-b033-f7264c3a3b6d',
  deploymentUid: '5b0398cf-97c7-426a-978e-02aa4aa51e2f',
  serviceName: 'self-adaptive-memory-allocation',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '4.5.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'self-adaptive-memory-allocation-dev-io', timeout: 500 };

try {
  const userHandler = require('./io-intensive-handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.server, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}