import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='tetzubko',
    application_name='memory-intensive',
    app_uid='X00J2Zt53995PCBn6r',
    org_uid='82ceb285-a0fb-4300-b033-f7264c3a3b6d',
    deployment_uid='2328f7a6-ac9a-45dc-90bb-cfaa46a3c936',
    service_name='self-adaptive-memory-allocation',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='4.5.2',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'self-adaptive-memory-allocation-dev-cpu', 'timeout': 500}
try:
    user_handler = serverless_sdk.get_user_handler('cpu-intensive-handler.testFunction')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
